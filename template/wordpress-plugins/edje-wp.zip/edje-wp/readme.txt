=== Edje WP Framework ===
Contributors: hrsetyono
Tags: framework, custom post type, admin, template, templates
Requires at least: 4.1
Stable tag: 0.3.0
Tested up to: 4.4.1
PHP version: 5.3.0 or greater
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Collection of code to help developers customize WordPress into full-fledged CMS.

== Description ==
WordPress allows tons of customization, but it's painfully complicated. Edje WP helps developers to do that.

Once Edje WP is installed and activated in your plugin directory, it gives any WordPress theme the ability to take advantage of our features.

Visit our [Documentation](https://github.com/hrsetyono/edje-wp) to get started.

**Note**: This plugin is still in Beta, use at your own risk.
