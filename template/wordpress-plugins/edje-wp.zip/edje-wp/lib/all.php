<?php
require_once 'utility.php';

require_once 'clear-default.php';
require_once 'post-column.php';
require_once 'post-type.php';
require_once 'taxonomy.php';
require_once 'post-filter.php';

require_once 'h-menu.php';
require_once 'h-submenu.php';

// require_once 'cpt2.php';
