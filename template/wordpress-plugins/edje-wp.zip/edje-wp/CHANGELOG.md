## 0.3.5

- Added `slug` argument to custom post type.

## 0.3.4

- Change double quote to single quote in PHP.
- Added URL Rewrite on CPT and Taxonomy to replace underscore with dash.

## 0.3.1

- Added `name` argument to custom taxonomy. `name` is the ID stored in database, `slug` is the URL for single taxonomy page.

## 0.3.0

- Ready to use.
