<?php
require_once 'hooks.php';
require_once 'javascript.php';
require_once 'template.php';
