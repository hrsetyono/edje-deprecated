# Edje WooCommerce

![Edje Wordpress](http://cdn.setyono.net/edge/wp-edge.jpg)

WooCommerce is a fantastic shopping platform, but complicated to use. This **plugin** brings order to that.

Visit our [WIKI](https://github.com/hrsetyono/edje-woo/wiki) for full documentation.

## Sample Features

**NEW VARIATION INTERFACE**

Important information in a glance, editable without toggling each variation.

![Edje Woo - New Variation Interface](http://cdn.setyono.net/edjewoo/variation.jpg)
