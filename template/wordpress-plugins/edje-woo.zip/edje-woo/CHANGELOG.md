## 0.3.1

- Automatically tick "Used for Variations" when adding new attribute
- Remove the code that hide some fields in Variation detail

## 0.3.0 - First Release

- Revamped interface for Variations
- Hide most fields from Variation detail
