<?php

/**
 * @ignore
 * @deprecated 0.21.9
 */
class TimberPage extends TimberPost {

}
