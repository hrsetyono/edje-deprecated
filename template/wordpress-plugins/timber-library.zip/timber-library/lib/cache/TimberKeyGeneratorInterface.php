<?php

namespace Timber\Cache;

interface TimberKeyGeneratorInterface {

	public function _get_cache_key();

}
