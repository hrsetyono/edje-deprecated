# timber-starter-theme

[![Build Status](https://travis-ci.org/Upstatement/timber-starter-theme.svg)](https://travis-ci.org/Upstatement/timber-starter-theme)

The "_s" for Timber: a dead-simple theme that you can build from
